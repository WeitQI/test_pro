#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
#send email
#create at 2013-04-22_01
#author huangyu

#import urllib.request, urllib.parse
import urllib
import urllib2
class SendMail():

  uid = "weitie@sogou-inc.com"
  frname = ""
  fraddr = "weitie@sogou-inc.com"
  title = "[Swift-Client]"
  body = "Your task have finished"
  mode = "html"
  attname = ""
  attbody = ""
  maillist = ""
  url = "http://portal.sys.sogou-op.org/portal/tools/send_mail.php"

  def __init__(self, contacts = None, message = None):
    self.message = message
    self.contacts = contacts
  def set_uid(self, uid):
    self.uid = uid

  def set_frname(self, frname):
    self.frname = frname

  def set_fraddr(self, fraddr):
    self.fraddr = fraddr

  def set_title(self, title):
    self.title = title

  def set_body(self, body):
    self.body = body

  def set_mode(self, mode):
    self.mode = mode

  def set_attname(self, attname):
    self.attname = attname

  def set_attbody(self, attbody):
    self.attbody = attbody

  def set_maillist(self, maillist):
    self.maillist = maillist

  def set_url(self, url):
    self.url = url

  def get_config(self):
    pass

  '''
  get mail title and body
  '''
  def get_content(self):
    try:
      self.title = str(self.message['title']).encode("gbk")
      self.body = str(self.message['body']).encode("gbk")
      return True
    except Exception as e:
      return False

  '''
  get contacts mails
  '''
  def get_maillist(self):
    contacts_list = self.contacts.split(',')
    maillist = ""
    for name in contacts_list:
      maillist += ";" + name + "@sogou-inc.com"
    if maillist == "":
      pass
    else:
      maillist = maillist[1:]
    return maillist

  def send_mail(self):
    send_mail_list = [("uid",self.uid),("fr_name",self.frname),("fr_addr",self.fraddr),("title",self.title),("body",self.body),("mode",self.mode),("maillist",self.maillist),("attname",self.attname),("attbody",self.attbody)]
    
	#post_data = urllib.parse.urlencode(send_mail_list)
    #post_data = post_data.encode(encoding='UTF-8')
    #final_url = urllib.request.Request(self.url, post_data)
    post_data = urllib.urlencode(send_mail_list)
    post_data = post_data.encode(encoding='UTF-8')
    final_url = urllib2.Request(self.url, post_data)

    try:
      response = urllib2.urlopen(final_url)
      return True
    except Exception as e:
      return False

  def main(self):
    if self.message == None:
      pass
    else:
      get_content_result = self.get_content()
    self.maillist = self.get_maillist()
    result = self.send_mail()
    return result
