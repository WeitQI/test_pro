#!/usr/bin/env python
#coding=utf-8

import os
#from webob import Request
from paste.deploy import loadapp
import os.path
import string
from eventlet.green.httplib import HTTPConnection
from swift.common.swob import Request
from hashlib import md5
import re
import sys
class UrlChange(object):
	def __init__(self,app,conf):
		self.app = app
		self.conf= conf
		self.auth_prefix = '/auth/'
	def __call__(self,env,start_response):
		if env.get('PATH_INFO','').startswith(self.auth_prefix) or env.get('PATH_INFO','').startswith('/v1/'):
			print 'urlchange.py 21 ----',env.get('PATH_INFO')
			pass
		else:
			if env.get('PATH_INFO') != '':
				print '************wget',env.get('PATH_INFO')
				env['PATH_INFO'] = '/v1'+env.get('PATH_INFO')
				print '[DEBUG for urlchange env.get(PATH_INFO) is ]',env.get('PATH_INFO')
				print '[DEBUG for urlchange env is ]',env
		req = Request(env)
		version,account,container,obj = req.split_path(1,4,True)
		
		if account.startswith('AUTH_'):
			print '[DEBUG for urlchange.py account is ]',account
		else:
			print '[DEBUG for urlchange.py account without AUTH_ is ]',account
			account = 'AUTH_' + account 
		if obj == None:
			pass
		else:
			if re.match(r'^/\d+/',obj) == None:
				conn = HTTPConnection('127.0.0.1:80')
				method = 'GET'
				path = '/v1/'+account+'/'+container
				conn.request(method,path,'')
				resp =conn.getresponse()
				resp_headers = {}
				for header,value in resp.getheaders():
					resp_headers[header.lower()] = value
				m =md5()
				m.update(obj)
				te = 'x-container-meta-'+str(m.hexdigest())
				pattern = re.compile(r'#(\d*)#') 
				print '[DEBUG for urlchange container-meta is::]',te
				if resp_headers.has_key(te):
					match = pattern.search(resp_headers[te])
					version = match.group(1)
					obj = version+'/'+obj
					print '[DEBUG for urlchange the PATH_INFO is ]   ',env['PATH_INFO']
					env['PATH_INFO'] = '/v1/'+account+'/'+container+'/'+obj
					print 'env[PATH_INFO]',env['PATH_INFO']
					
		return self.app(env,start_response)

def filter_factory(global_conf,**local_conf):
	
	conf = global_conf.copy()
	conf.update(local_conf)
	def auth_filter(app):
		return UrlChange(app,conf)
	return auth_filter
	#req_usernames = kwargs['userlist']
	#def filter(app):
	#	return Sogou(app,req_usernames)
	#return filter
		
