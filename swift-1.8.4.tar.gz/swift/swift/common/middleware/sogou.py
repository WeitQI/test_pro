#!/usr/bin/env python
#coding=utf-8

import os
from webob import Request
from webob import Response
from paste.deploy import loadapp
import os.path
import string


class UrlChange(object):
	def __init__(self,app,conf):
		self.app = app
		self.conf= conf
		self.auth_prefix = '/auth/'
	def __call__(self,env,start_response):
		if env.get('PATH_INFO','').startswith(self.auth_prefix) or env.get('PATH_INFO','').startswith('/v1/'):
			pass
		else:
			if env.get('PATH_INFO') != '':
				env['PATH_INFO'] = '/v1'+env.get('PATH_INFO')
				print '[sogou--DEBUG]',env.get('PATH_INFO')
		
		return self.app(env,start_response)

def filter_factory(global_conf,**local_conf):
	
	conf = global_conf.copy()
	conf.update(local_conf)
	def auth_filter(app):
		return UrlChange(app,conf)
	return auth_filter
	#req_usernames = kwargs['userlist']
	#def filter(app):
	#	return Sogou(app,req_usernames)
	#return filter
		
