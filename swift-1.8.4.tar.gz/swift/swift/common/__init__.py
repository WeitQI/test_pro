""" Code common to all of Swift. """
