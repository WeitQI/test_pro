#!/usr/bin/env python
#coding=utf-8

from urllib import unquote 
from swift.common.utils import cache_from_env

class GetMd5Controller(Controller):
	"""
	WSGI controller for Real-time monitoring
	"""
	def __init__(self,app,account_name,container_name,***kwargs):
		Controller.__init__(self,app)
		self.account_name = unquote(account_name)
		self.container_name = unquote(container_name)
		self.memcache = cache_from_env(req.environ)
	def GETorHEAD(self, req):
		"""
		Handler for HTTP HEAD requests
		"""


